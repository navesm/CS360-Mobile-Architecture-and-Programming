package com.zybooks.inventoryapp_stevennave;

public class InventoryItem {
    private int id;
    private String name;
    private int quantity;
    private String dateAdded;

    public InventoryItem(int id, String name, int quantity, String dateAdded) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.dateAdded = dateAdded;
    }

    // Getters
    public int getId() { return id; }
    public String getName() { return name; }
    public int getQuantity() { return quantity; }
    public String getDateAdded() { return dateAdded; }

    // Setter for quantity
    public void setQuantity(int quantity) { this.quantity = quantity; }
}